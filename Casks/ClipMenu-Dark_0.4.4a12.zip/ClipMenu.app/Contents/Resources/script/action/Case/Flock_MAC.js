var lines = clipText.split('\n');

for (var i = 0; i < lines.length; i++) {
    lines[i] = lines[i].toUpperCase();
    lines[i] = lines[i].replace(/:/g, "");
}

return lines.join('\n');

