return "'" + clipText + "'";

