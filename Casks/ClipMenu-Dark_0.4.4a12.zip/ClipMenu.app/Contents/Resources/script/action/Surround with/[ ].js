return '[' + clipText + ']';

