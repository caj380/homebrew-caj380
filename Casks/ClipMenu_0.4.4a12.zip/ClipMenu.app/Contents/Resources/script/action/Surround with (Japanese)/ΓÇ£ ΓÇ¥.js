return '“' + clipText + '”';

