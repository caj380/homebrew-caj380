return encodeURIComponent(clipText);

